# HelloGE2D
Simple demonstration of GE2D hardware blit engine on Odroid-C1

To compile:
  gcc main.cpp -o HelloGE2D
  
To run (you must be root to run):
  sudo ./HelloGE2D
  
